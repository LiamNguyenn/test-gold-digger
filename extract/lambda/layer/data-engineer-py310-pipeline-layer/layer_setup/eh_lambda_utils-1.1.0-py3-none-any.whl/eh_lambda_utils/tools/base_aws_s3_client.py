"""AWS S3 Client base on BaseAwsClient - simply s3 client from session inherited."""
import io
import logging
from typing import Any

import boto3
from attrs import Factory, define, field

from .base_aws_client import BaseAwsClient

logging.basicConfig(
    level=logging.INFO, format="%(levelname)s - %(asctime)s - %(message)s"
)


@define
class BaseAwsS3Client(BaseAwsClient):
    """AWS S3 Client base on BaseAwsClient - simply s3 client from session inherited."""

    s3_client: boto3.client = field(
        default=Factory(lambda self: self.session.client("s3"), takes_self=True),
        kw_only=True,
    )

    def get_bucket_acl(self, bucket_name: str) -> str:
        """
        Can be used to get an access control list (ACL) of an AWS S3 bucket.

        :param bucket_name: The bucket name that contains the object for which to get the ACL information.
        :return:
        """
        try:
            acl = self.s3_client.get_bucket_acl(Bucket=bucket_name)
            return str(acl)
        except Exception as e:  # noqa: BLE001
            raise Exception(  # noqa: TRY003, TRY002
                f"error getting bucket acl {e}"
            ) from e

    def get_bucket_policy(self, bucket_name: str) -> str:
        """
        Can be used to get an AWS S3 bucket policy.

        :param bucket_name: The bucket name for which to get the bucket policy.
        :return:
        """
        try:
            policy = self.s3_client.get_bucket_policy(Bucket=bucket_name)
            return str(policy)
        except Exception as e:  # noqa: BLE001
            raise Exception(  # noqa: TRY003, TRY002
                f"error getting bucket policy {e}"
            ) from e

    def get_object_acl(self, bucket_name: str, object_key: str) -> str:
        """
        Can be used to get an access control list (ACL) of an object in the AWS S3 bucket.

        :param bucket_name: Name of the AWS S3 bucket for which to get an ACL.
        :param object_key: Key of the object for which to get the ACL information.
        :return:
        """
        try:
            acl = self.s3_client.get_object_acl(Bucket=bucket_name, Key=object_key)
            return str(acl)
        except Exception as e:  # noqa: BLE001
            raise Exception(  # noqa: TRY003, TRY002
                f"error getting object acl {e}"
            ) from e

    def list_s3_buckets(self) -> list:
        """
        Can be used to list all AWS S3 buckets.

        :return: list of buckets that can be seen
        """
        try:
            buckets = self.s3_client.list_buckets()

            return [str(b) for b in buckets["Buckets"]]
        except Exception as e:  # noqa: BLE001
            raise Exception(  # noqa: TRY003, TRY002
                f"error listing s3 buckets {e}"
            ) from e

    def list_objects(self, bucket_name: str) -> list:
        """
        Can be used to list all objects in an AWS S3 bucket.

        :param bucket_name: The name of the S3 bucket to list.
        :return:
        """
        try:
            objects = self.s3_client.list_objects_v2(Bucket=bucket_name)

            return [str(o) for o in objects["Contents"]]
        except Exception as e:  # noqa: BLE001
            raise Exception(  # noqa: TRY003, TRY002
                f"error listing objects in bucket {e}"
            ) from e

    def _upload_object(
        self, bucket_name: str, object_name: str, value: Any, extra_args: dict | None
    ) -> None:
        self.s3_client.upload_fileobj(
            Fileobj=io.BytesIO(value.encode() if isinstance(value, str) else value),
            Bucket=bucket_name,
            Key=object_name,
            ExtraArgs=extra_args,
        )
        logging.info(f"SUCCESSFUL WRITE FILE TO s3://{bucket_name}/{object_name}")
