"""AWS S3 Client base on BaseAwsClient - simply s3 client from session inherited."""
import gzip
import io
import json
import logging

from attrs import define

from ..models import S3UploadResponse  # noqa: TID252
from .base_aws_s3_client import BaseAwsS3Client

logging.basicConfig(
    level=logging.INFO, format="%(levelname)s - %(asctime)s - %(message)s"
)


@define
class AwsS3Client(BaseAwsS3Client):
    """AWS S3 Client base on BaseAwsClient - simply s3 client from session inherited."""

    def upload_string_content_to_s3(
        self,
        content: str,
        bucket_name: str,
        object_key: str,
        extra_args: dict | None = None,
    ) -> None:
        """
        Can be used to upload content to an AWS S3 bucket.

        :param content:
        :param bucket_name:
        :param object_key: Destination object key name. For example, 'baz.txt'
        :param extra_args: Extra arguments that may be passed to the client operation. For allowed upload arguments see boto3.s3.transfer.S3Transfer.ALLOWED_UPLOAD_ARGS.
        :return:
        """
        try:
            self._upload_object(bucket_name, object_key, content, extra_args)
        except Exception as e:  # noqa: BLE001
            raise Exception(  # noqa: TRY003, TRY002
                f"error uploading string objects to the bucket {e}"
            ) from e

    def upload_and_compress_gzip_file_to_s3(
        self,
        byte_value: io.BytesIO,
        bucket_name: str,
        prefix: str,
        file_name: str,
        extra_args: dict | None = None,
    ) -> S3UploadResponse:
        """
        Can be used to upload content to an AWS S3 bucket, compress in GZ format.

        :param byte_value: byte value of object want to upload
        :param bucket_name: Destination bucket name
        :param prefix: prefix of object key name. For example, 'ABC/DEF'
        :param file_name: Destination file name. For example, 'baz.txt'
        :param extra_args: Extra arguments that may be passed to the client operation. For allowed upload arguments see boto3.s3.transfer.S3Transfer.ALLOWED_UPLOAD_ARGS.
        :return:
        """
        try:
            upload_object = gzip.compress(byte_value.getvalue())
            object_key = f"{prefix}/{file_name}"
            self._upload_object(bucket_name, object_key, upload_object, extra_args)
            return S3UploadResponse(
                file_name=file_name,
                s3_destination_bucket=bucket_name,
                s3_destination_key=object_key,
            )

        except Exception as e:  # noqa: BLE001
            raise Exception(  # noqa: TRY003, TRY002
                f"error uploading objects to the bucket {e}"
            ) from e

    def upload_file_to_s3(
        self,
        byte_value: io.BytesIO,
        bucket_name: str,
        prefix: str,
        file_name: str,
        extra_args: dict | None = None,
    ) -> S3UploadResponse:
        """
        Can be used to upload content to an AWS S3 bucket, non compress.

        :param byte_value: byte value of object want to upload
        :param bucket_name: Destination bucket name
        :param prefix: prefix of object key name. For example, 'ABC/DEF'
        :param file_name: Destination file name. For example, 'baz.txt'
        :param extra_args: Extra arguments that may be passed to the client operation. For allowed upload arguments see boto3.s3.transfer.S3Transfer.ALLOWED_UPLOAD_ARGS.
        :return:
        """
        try:
            object_key = f"{prefix}/{file_name}"
            self._upload_object(bucket_name, object_key, byte_value, extra_args)
            return S3UploadResponse(
                file_name=file_name,
                s3_destination_bucket=bucket_name,
                s3_destination_key=object_key,
            )
        except Exception as e:  # noqa: BLE001
            raise Exception(  # noqa: TRY003, TRY002
                f"error uploading objects to the bucket {e}"
            ) from e

    def construct_and_upload_manifest(
        self,
        detail_files_info: list[S3UploadResponse],
        bucket_name: str,
        prefix: str,
        file_name: str,
        extra_args: dict | None,
    ) -> S3UploadResponse:
        """
        Can be used to construct manifest file and push to S3 for further consumption.

        :param detail_files_info: list of S3UploadResponse
        :param bucket_name: Destination bucket name
        :param prefix: prefix of object key name. For example, 'ABC/DEF'
        :param file_name: Destination file name. For example, 'baz.txt'
        :param extra_args: Extra arguments that may be passed to the client operation. For allowed upload arguments see boto3.s3.transfer.S3Transfer.ALLOWED_UPLOAD_ARGS.
        :return:
        """
        try:
            entries = [
                {
                    "url": f"s3://{file_info.s3_destination_bucket}/{file_info.s3_destination_key}",
                    "mandatory": True,
                }
                for file_info in detail_files_info
            ]
            upload_object = json.dumps({"entries": entries})
            object_key = f"{prefix}/{file_name}"
            self._upload_object(bucket_name, object_key, upload_object, extra_args)
            res = S3UploadResponse(
                file_name=file_name,
                s3_destination_bucket=bucket_name,
                s3_destination_key=object_key,
            )
        except Exception as e:  # noqa: BLE001
            raise Exception(  # noqa: TRY003, TRY002
                f"error uploading manifest objects to the bucket {e}"
            ) from e
        else:
            logging.info(
                f"SUCCESSFUL WRITE MANIFEST FILE TO "
                f"s3://{res.s3_destination_bucket}/{res.s3_destination_key}"
            )
            return res
