"""Redshift SQL Driver base on BaseSqlDriver for easier handle redshift, base on boto3 redshift-data client."""
import logging
import time
from typing import Any

import boto3
from attrs import Factory, define, field

from .base_sql_driver import BaseSqlDriver

logging.basicConfig(
    level=logging.INFO, format="%(levelname)s - %(asctime)s - %(message)s"
)


@define
class BaseRedshiftSqlDriver(BaseSqlDriver):
    """Redshift SQL Driver base on BaseSqlDriver for easier handle redshift, base on boto3 redshift-data client."""

    database: str = field(kw_only=True)
    session: boto3.session = field(kw_only=True)
    cluster_identifier: str | None = field(default=None, kw_only=True)
    workgroup_name: str | None = field(default=None, kw_only=True)
    db_user: str | None = field(default=None, kw_only=True)
    database_credentials_secret_arn: str | None = field(default=None, kw_only=True)
    wait_for_query_completion_sec: float = field(default=0.3, kw_only=True)
    client: boto3.client = field(
        default=Factory(
            lambda self: self.session.client("redshift-data"), takes_self=True
        ),
        kw_only=True,
    )

    @workgroup_name.validator  # type: ignore[union-attr]
    def validate_params(
        self, _, workgroup_name: str | None  # noqa: ARG002
    ) -> None:  # force to have 3rd argument due to field validator
        """Use validator function of field decorator."""
        if not self.cluster_identifier and not self.workgroup_name:
            raise ValueError(  # noqa: TRY003
                "Provide a value for one of `cluster_identifier` or `workgroup_name`"
            )
        elif (  # noqa: RET506 - False positive
            self.cluster_identifier and self.workgroup_name
        ):
            raise ValueError(  # noqa: TRY003
                "Provide a value for either `cluster_identifier` or `workgroup_name`, but not both"
            )

    @classmethod
    def _process_rows_from_records(cls, records) -> list[list]:
        return [[c[next(iter(c.keys()))] for c in r] for r in records]

    @classmethod
    def _process_cells_from_rows_and_columns(
        cls, columns: list, rows: list[list]
    ) -> list[dict[str, Any]]:
        return [{column: r[idx] for idx, column in enumerate(columns)} for r in rows]

    @classmethod
    def _process_columns_from_column_metadata(cls, meta) -> list:
        return [k["name"] for k in meta]

    @classmethod
    def _post_process(cls, meta, records) -> list[dict[str, Any]]:
        columns = cls._process_columns_from_column_metadata(meta)
        rows = cls._process_rows_from_records(records)
        return cls._process_cells_from_rows_and_columns(columns, rows)

    def execute_query(self, query: str) -> list:
        """
        Handle query statement (SELECT) -> wait for results.

        @param query: sql query
        @return:
        """
        rows = self.execute_query_raw(query)
        if rows:
            return rows
        return []

    def execute_query_raw(self, query: str) -> list[dict[str, Any]]:
        """
        Handle query statement (SELECT) raw -> wait for results.

        @param query: sql query
        @return:
        """
        function_kwargs = {"Sql": query, "Database": self.database}
        if self.workgroup_name:
            function_kwargs["WorkgroupName"] = self.workgroup_name
        if self.cluster_identifier:
            function_kwargs["ClusterIdentifier"] = self.cluster_identifier
        if self.db_user:
            function_kwargs["DbUser"] = self.db_user
        if self.database_credentials_secret_arn:
            function_kwargs["SecretArn"] = self.database_credentials_secret_arn

        response = self.client.execute_statement(**function_kwargs)
        response_id = response["Id"]

        statement = self.client.describe_statement(Id=response_id)

        while statement["Status"] not in ["FINISHED", "ABORTED", "FAILED"]:
            time.sleep(self.wait_for_query_completion_sec)
            statement = self.client.describe_statement(Id=response_id)

        if statement["Status"] == "FINISHED":
            statement_result = self.client.get_statement_result(Id=response_id)
            results = statement_result.get("Records", [])

            while "NextToken" in statement_result:
                statement_result = self.client.get_statement_result(
                    Id=response_id, NextToken=statement_result["NextToken"]
                )
                results = results + response.get("Records", [])

            return self._post_process(statement_result["ColumnMetadata"], results)
        return []

    def get_table_schema(self, table: str, schema: str | None = None) -> list:
        """
        Return table schema detail - name, datatype, etc.

        @param table: table to look for
        @param schema: schema of table to look for
        @return:
        """
        function_kwargs = {"Database": self.database, "Table": table}
        if schema:
            function_kwargs["Schema"] = schema
        if self.workgroup_name:
            function_kwargs["WorkgroupName"] = self.workgroup_name
        if self.cluster_identifier:
            function_kwargs["ClusterIdentifier"] = self.cluster_identifier
        if self.db_user:
            function_kwargs["DbUser"] = self.db_user
        if self.database_credentials_secret_arn:
            function_kwargs["SecretArn"] = self.database_credentials_secret_arn
        response = self.client.describe_table(**function_kwargs)
        return response.get("ColumnList", [])

    def execute_statement_raw(self, query: str):
        """
        Handle execute statement (CREATE, DELETE, etc) raw -> wait for response.

        @param query: sql statement
        @return:
        """
        function_kwargs = {"Sql": query, "Database": self.database}
        if self.workgroup_name:
            function_kwargs["WorkgroupName"] = self.workgroup_name
        if self.cluster_identifier:
            function_kwargs["ClusterIdentifier"] = self.cluster_identifier
        if self.db_user:
            function_kwargs["DbUser"] = self.db_user
        if self.database_credentials_secret_arn:
            function_kwargs["SecretArn"] = self.database_credentials_secret_arn

        response = self.client.execute_statement(**function_kwargs)
        response_id = response["Id"]

        statement = self.client.describe_statement(Id=response_id)
        while statement["Status"] not in ["FINISHED", "ABORTED", "FAILED"]:
            time.sleep(self.wait_for_query_completion_sec)
            statement = self.client.describe_statement(Id=response_id)
        if statement["Status"] != "FINISHED":
            raise Exception(  # noqa: TRY002, TRY003
                f"execute statement error {statement}"
            )
